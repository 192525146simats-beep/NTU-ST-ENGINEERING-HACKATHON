#!/usr/bin/env python3
"""
Synthora Pure-Python OpenXML (.docx) Document Generator
Creates real, fully valid Microsoft Word documents with zero external C-dependencies.
"""

import os
import zipfile
import xml.sax.saxutils as saxutils
from typing import List, Dict, Any, Optional

class DocxReportBuilder:
    """Constructs valid Microsoft Word .docx files conforming to ISO/IEC 29500 (OpenXML)."""

    def __init__(self, title: str = "Executive Report"):
        self.title = title
        self.paragraphs: List[Dict[str, Any]] = []
        self.tables: List[Dict[str, Any]] = []

    def add_heading(self, text: str, level: int = 1):
        self.paragraphs.append({"type": "heading", "level": level, "text": text})

    def add_paragraph(self, text: str, bold: bool = False, italic: bool = False):
        self.paragraphs.append({"type": "paragraph", "text": text, "bold": bold, "italic": italic})

    def add_table(self, headers: List[str], rows: List[List[str]]):
        self.tables.append({"headers": headers, "rows": rows})

    def save(self, filepath: str) -> str:
        os.makedirs(os.path.dirname(os.path.abspath(filepath)), exist_ok=True)
        
        # Build word/document.xml
        body_xml = []
        for p in self.paragraphs:
            clean_text = saxutils.escape(p["text"])
            if p["type"] == "heading":
                sz = "36" if p["level"] == 1 else "28"
                color = "0066FF" if p["level"] == 1 else "1E293B"
                body_xml.append(f"""
                <w:p>
                    <w:pPr>
                        <w:spacing w:before="240" w:after="120"/>
                        <w:rPr>
                            <w:b/>
                            <w:color w:val="{color}"/>
                            <w:sz w:val="{sz}"/>
                        </w:rPr>
                    </w:pPr>
                    <w:r>
                        <w:rPr>
                            <w:b/>
                            <w:color w:val="{color}"/>
                            <w:sz w:val="{sz}"/>
                        </w:rPr>
                        <w:t>{clean_text}</w:t>
                    </w:r>
                </w:p>
                """)
            else:
                b_tag = "<w:b/>" if p.get("bold") else ""
                i_tag = "<w:i/>" if p.get("italic") else ""
                body_xml.append(f"""
                <w:p>
                    <w:pPr>
                        <w:spacing w:after="140" w:line="276" w:lineRule="auto"/>
                    </w:pPr>
                    <w:r>
                        <w:rPr>{b_tag}{i_tag}<w:sz w:val="22"/><w:color w:val="334155"/></w:rPr>
                        <w:t>{clean_text}</w:t>
                    </w:r>
                </w:p>
                """)

        # Add tables
        for t in self.tables:
            tbl_xml = ['<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/><w:tblBorders><w:top w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/><w:bottom w:val="single" w:sz="8" w:space="0" w:color="0066FF"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="E2E8F0"/></w:tblBorders></w:tblPr>']
            # Header Row
            tbl_xml.append('<w:tr><w:trPr><w:tblHeader/></w:trPr>')
            for h in t["headers"]:
                tbl_xml.append(f'<w:tc><w:tcPr><w:shd w:val="clear" w:color="auto" w:fill="F1F5F9"/></w:tcPr><w:p><w:r><w:rPr><w:b/><w:sz w:val="20"/><w:color w:val="0F172A"/></w:rPr><w:t>{saxutils.escape(str(h))}</w:t></w:r></w:p></w:tc>')
            tbl_xml.append('</w:tr>')
            # Data Rows
            for row in t["rows"]:
                tbl_xml.append('<w:tr>')
                for cell in row:
                    tbl_xml.append(f'<w:tc><w:p><w:r><w:rPr><w:sz w:val="20"/><w:color w:val="334155"/></w:rPr><w:t>{saxutils.escape(str(cell))}</w:t></w:r></w:p></w:tc>')
                tbl_xml.append('</w:tr>')
            tbl_xml.append('</w:tbl>')
            body_xml.append("".join(tbl_xml))

        document_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
            <w:body>
                {''.join(body_xml)}
                <w:sectPr>
                    <w:pgSz w:w="12240" w:h="15840"/>
                    <w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/>
                </w:sectPr>
            </w:body>
        </w:document>
        """

        content_types_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
            <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
            <Default Extension="xml" ContentType="application/xml"/>
            <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
        </Types>"""

        rels_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
            <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
        </Relationships>"""

        with zipfile.ZipFile(filepath, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("[Content_Types].xml", content_types_xml)
            zf.writestr("_rels/.rels", rels_xml)
            zf.writestr("word/document.xml", document_xml)

        return filepath
