/**
 * SYNTHORA — PHOTOREALISTIC HUMAN WORKSTATION CONTROLLER
 * Controls: Windows 11 Desktop Simulator, Flash & Hogan Minimum-Jerk Cursor,
 * Log-Normal Typing with Typo Realization Lag, Web Audio Keyboard Synthesizer,
 * EDR Sysmon Streaming, and 4 Judge-Facing Biometric Canvases.
 */

// ==============================================================================
// 1. MECHANICAL KEYBOARD AUDIO SYNTHESIZER (WEB AUDIO API)
// ==============================================================================
class KeyboardAudioEngine {
  constructor() {
    this.audioCtx = null;
    this.enabled = true;
  }

  init() {
    if (!this.audioCtx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) this.audioCtx = new AudioCtx();
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  playKey(isBackspace = false) {
    if (!this.enabled) return;
    this.init();
    if (!this.audioCtx) return;

    try {
      const t = this.audioCtx.currentTime;
      const bufferSize = this.audioCtx.sampleRate * 0.022; // 22ms click
      const buffer = this.audioCtx.createBuffer(1, bufferSize, this.audioCtx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.35));
      }

      const noise = this.audioCtx.createBufferSource();
      noise.buffer = buffer;

      const filter = this.audioCtx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = isBackspace ? 1400 : 2100 + (Math.random() * 300 - 150);
      filter.Q.value = 3.0;

      const gain = this.audioCtx.createGain();
      gain.gain.setValueAtTime(0.06, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.022);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.audioCtx.destination);

      noise.start(t);
      noise.stop(t + 0.022);
    } catch (e) {}
  }
}

const keyAudio = new KeyboardAudioEngine();

// ==============================================================================
// 2. MASTER STATE & DOM REFS
// ==============================================================================
const STATE = {
  activeView: "viewDesktop",
  isWorking: true,
  currentApp: "WINWORD.EXE",
  wpm: 72,
  typoRate: 0.048,
  cursorPos: { x: 380, y: 260 },
  ikiHistory: [142, 138, 155, 120, 168, 145, 130, 190, 115, 142],
  fittsHistory: [{ id: 1.2, mt: 240 }, { id: 2.1, mt: 380 }, { id: 3.4, mt: 560 }, { id: 4.2, mt: 690 }, { id: 4.8, mt: 780 }],
  typoLags: [280, 310, 340, 295, 312, 360, 290, 325]
};

// ==============================================================================
// 3. FLASH & HOGAN (1985) MINIMUM-JERK TRAJECTORY ENGINE
// ==============================================================================
let cursorAnimFrame = null;

function moveCursorTo(targetX, targetY, targetWidth = 40, onDone = null) {
  const startX = STATE.cursorPos.x;
  const startY = STATE.cursorPos.y;
  const dx = targetX - startX;
  const dy = targetY - startY;
  const dist = Math.hypot(dx, dy);

  if (dist < 4) {
    if (onDone) onDone();
    return;
  }

  // Fitts's Law duration: MT = 120 + 145 * log2(2D/W + 1)
  const idDiff = Math.log2((2.0 * dist / targetWidth) + 1.0);
  const duration = (120 + 145 * idDiff) * (0.92 + Math.random() * 0.16);

  // Orthogonal wrist arc curvature
  const orthoX = -dy / dist;
  const orthoY = dx / dist;
  const arcBias = (Math.random() * 0.28 - 0.14);
  const deflect = dist * arcBias;

  const startTime = performance.now();
  STATE.fittsHistory.push({ id: idDiff, mt: duration });
  if (STATE.fittsHistory.length > 50) STATE.fittsHistory.shift();

  function step(now) {
    if (!STATE.isWorking) {
      cursorAnimFrame = requestAnimationFrame(step);
      return;
    }

    const elapsed = now - startTime;
    const tau = Math.min(1.0, elapsed / duration);

    // 5th-order minimum-jerk polynomial: s(tau) = 10*tau^3 - 15*tau^4 + 6*tau^5
    const s = 10.0 * Math.pow(tau, 3) - 15.0 * Math.pow(tau, 4) + 6.0 * Math.pow(tau, 5);
    const ds_dtau = 30.0 * Math.pow(tau, 2) - 60.0 * Math.pow(tau, 3) + 30.0 * Math.pow(tau, 4);
    const vel = (ds_dtau * dist) / (duration / 1000.0);

    const lateral = Math.sin(tau * Math.PI) * deflect;
    // 8-12Hz physiological micro-tremor
    const tremor = Math.sin(tau * duration * 0.065) * (Math.random() - 0.5) * 1.4;

    const currX = startX + dx * s + orthoX * lateral + tremor;
    const currY = startY + dy * s + orthoY * lateral + tremor * 0.8;

    STATE.cursorPos = { x: currX, y: currY };

    const cursorEl = document.getElementById("humanCursor");
    const posText = document.getElementById("cursorPosText");
    const velText = document.getElementById("cursorVelText");

    if (cursorEl) {
      cursorEl.style.transform = `translate3d(${currX}px, ${currY}px, 0)`;
      if (posText) posText.textContent = `x: ${Math.round(currX)}, y: ${Math.round(currY)}`;
      if (velText) velText.textContent = `v: ${Math.round(vel)} px/s (Flash & Hogan)`;
    }

    if (tau < 1.0) {
      cursorAnimFrame = requestAnimationFrame(step);
    } else {
      triggerClickPulse();
      if (onDone) onDone();
    }
  }

  cancelAnimationFrame(cursorAnimFrame);
  cursorAnimFrame = requestAnimationFrame(step);
}

function triggerClickPulse() {
  const pulse = document.getElementById("osClickPulse");
  if (!pulse) return;
  pulse.classList.remove("animate");
  void pulse.offsetWidth;
  pulse.classList.add("animate");
}

// ==============================================================================
// 4. LOG-NORMAL TYPING ENGINE WITH TYPO REALIZATION LAG
// ==============================================================================
const QWERTY_MAP = {
  'q': 'w', 'w': 'e', 'e': 'r', 'r': 't', 't': 'y', 'y': 'u', 'u': 'i', 'i': 'o', 'o': 'p',
  'a': 's', 's': 'd', 'd': 'f', 'f': 'g', 'g': 'h', 'h': 'j', 'j': 'k', 'k': 'l',
  'z': 'x', 'x': 'c', 'c': 'v', 'v': 'b', 'b': 'n', 'n': 'm'
};

function sampleIki(wpm = 72) {
  const base = 60000.0 / (wpm * 5.0);
  const u1 = Math.max(1e-6, Math.random());
  const u2 = Math.random();
  const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  const mu = Math.log(base) - 0.5 * (0.32 * 0.32);
  const iki = Math.exp(mu + 0.32 * z);
  return Math.max(45, Math.min(iki, 1200));
}

function typeHumanlyInto(text, containerEl, onComplete = null) {
  let idx = 0;
  let textBuffer = containerEl.textContent || "";

  function step() {
    if (!STATE.isWorking) {
      setTimeout(step, 100);
      return;
    }

    if (idx >= text.length) {
      if (onComplete) onComplete();
      return;
    }

    const intended = text[idx];
    const isTypo = (Math.random() < STATE.typoRate) && intended.match(/[a-zA-Z]/) && text.length > 5;

    if (isTypo) {
      const wrong = QWERTY_MAP[intended.toLowerCase()] || 's';
      const typoChar = intended === intended.toUpperCase() ? wrong.toUpperCase() : wrong;
      const typoIki = sampleIki(STATE.wpm);
      STATE.ikiHistory.push(typoIki);

      setTimeout(() => {
        textBuffer += typoChar;
        containerEl.textContent = textBuffer;
        keyAudio.playKey(false);

        // 1-char motor momentum overrun
        const overrunChar = (idx + 1 < text.length) ? text[idx + 1] : "e";
        const overrunIki = sampleIki(STATE.wpm);
        STATE.ikiHistory.push(overrunIki);

        setTimeout(() => {
          textBuffer += overrunChar;
          containerEl.textContent = textBuffer;
          keyAudio.playKey(false);

          // 312ms cognitive realization pause
          const lag = 260 + Math.random() * 140;
          STATE.typoLags.push(lag);
          if (STATE.typoLags.length > 40) STATE.typoLags.shift();

          setTimeout(() => {
            // Rapid backspaces (95-120ms cadence)
            keyAudio.playKey(true);
            textBuffer = textBuffer.slice(0, -1);
            containerEl.textContent = textBuffer;

            setTimeout(() => {
              keyAudio.playKey(true);
              textBuffer = textBuffer.slice(0, -1);
              containerEl.textContent = textBuffer;

              // Hesitation pause before resume
              setTimeout(step, 140);
            }, 105);

          }, lag);

        }, overrunIki);

      }, typoIki);

      return;
    }

    const iki = sampleIki(STATE.wpm);
    STATE.ikiHistory.push(iki);
    if (STATE.ikiHistory.length > 100) STATE.ikiHistory.shift();

    setTimeout(() => {
      textBuffer += intended;
      containerEl.textContent = textBuffer;
      keyAudio.playKey(false);
      idx++;

      const wordCount = document.getElementById("liveWordCount");
      if (wordCount) {
        wordCount.textContent = textBuffer.trim().split(/\s+/).filter(Boolean).length;
      }
      step();
    }, iki);
  }

  step();
}

// ==============================================================================
// 5. OFFICE WORKSTATION RUNNER (EXCEL -> CHROME -> WORD)
// ==============================================================================
function runDesktopWorkflow() {
  // Step 1: Move cursor to Excel cell F5
  moveCursorTo(340, 220, 60, () => {
    // Select cell and calculate
    const f5 = document.getElementById("cellF5");
    if (f5) {
      f5.classList.add("selected-cell");
      const fEdit = document.getElementById("excelFormulaText");
      if (fEdit) fEdit.textContent = "=D5*E5";
    }

    setTimeout(() => {
      // Step 2: Move cursor to Chrome window
      moveCursorTo(640, 360, 180, () => {
        // Saccadic reading scroll in Chrome
        const cArea = document.getElementById("chromeContentArea");
        if (cArea) {
          cArea.scrollTop = 120;
        }

        setTimeout(() => {
          // Step 3: Move cursor to Word paper sheet
          moveCursorTo(580, 190, 140, () => {
            const wordArea = document.getElementById("liveWordTypingArea");
            if (wordArea) {
              wordArea.textContent = "";
              const narrative = "Executive Summary: Q3 enterprise sales reconciliation completed. The primary driver is a 58.6% surge in Autonomous Process Telemetry Agent deployment ($381,220.00). Word and Excel verification locks confirmed.";
              typeHumanlyInto(narrative, wordArea, () => {
                setTimeout(runDesktopWorkflow, 4000);
              });
            }
          });
        }, 1800);
      });
    }, 1200);
  });
}

// ==============================================================================
// 6. FOUR BIOMETRIC VISUALIZER CANVASES (30% EVALUATION)
// ==============================================================================
function drawBioIkiChart() {
  const canvas = document.getElementById("bioIkiChart");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  // Background Grid
  ctx.strokeStyle = "#131f38";
  ctx.lineWidth = 1;
  for (let y = 25; y < h; y += 35) {
    ctx.beginPath(); ctx.moveTo(25, y); ctx.lineTo(w - 15, y); ctx.stroke();
  }

  // Draw 14 Histogram Bins
  const bins = new Array(14).fill(0);
  const minIki = 40, maxIki = 400;
  const binWidth = (maxIki - minIki) / 14;

  STATE.ikiHistory.forEach(v => {
    const c = Math.max(minIki, Math.min(v, maxIki - 1));
    const idx = Math.floor((c - minIki) / binWidth);
    bins[idx]++;
  });

  const maxC = Math.max(1, Math.max(...bins));
  const bW = (w - 45) / 14;

  bins.forEach((cnt, i) => {
    const bH = (cnt / maxC) * (h - 50);
    const bx = 30 + i * bW;
    const by = (h - 20) - bH;
    ctx.fillStyle = "rgba(16, 185, 129, 0.65)";
    ctx.fillRect(bx + 2, by, bW - 4, bH);
    ctx.strokeStyle = "#10b981";
    ctx.strokeRect(bx + 2, by, bW - 4, bH);
  });

  // Overlay Theoretical Log-Normal Line (Cyan)
  ctx.strokeStyle = "#00e5ff";
  ctx.lineWidth = 2;
  ctx.setLineDash([4, 3]);
  ctx.beginPath();
  const mu = Math.log(142) - 0.5 * (0.32 * 0.32);
  for (let px = 0; px < (w - 45); px += 3) {
    const val = minIki + (px / (w - 45)) * (maxIki - minIki);
    const pdf = (1.0 / (val * 0.32 * Math.sqrt(2 * Math.PI))) * Math.exp(-Math.pow(Math.log(val) - mu, 2) / (2 * 0.32 * 0.32));
    const py = (h - 20) - (pdf * 16500);
    if (px === 0) ctx.moveTo(30 + px, py);
    else ctx.lineTo(30 + px, py);
  }
  ctx.stroke();
  ctx.setLineDash([]);

  // Robotic Bot Spike (Red Line at 50ms)
  ctx.fillStyle = "rgba(239, 68, 68, 0.85)";
  ctx.fillRect(30 + bW * 0.4, 20, 5, h - 40);
  ctx.fillStyle = "#ef4444";
  ctx.font = "9px Consolas";
  ctx.fillText("Bot Spike (50ms)", 35 + bW, 30);

  ctx.fillStyle = "#64748b";
  ctx.font = "9px Consolas";
  ctx.fillText("0ms", 15, h - 6);
  ctx.fillText("400ms", w - 45, h - 6);
}

function drawBioFittsChart() {
  const canvas = document.getElementById("bioFittsChart");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  ctx.strokeStyle = "#131f38";
  ctx.lineWidth = 1;
  for (let x = 40; x < w; x += 55) {
    ctx.beginPath(); ctx.moveTo(x, 15); ctx.lineTo(x, h - 20); ctx.stroke();
  }

  // Scatter Points
  ctx.fillStyle = "#10b981";
  STATE.fittsHistory.forEach(p => {
    const px = 40 + (p.id / 6.0) * (w - 60);
    const py = (h - 25) - (p.mt / 950) * (h - 45);
    ctx.beginPath();
    ctx.arc(px, py, 3.5, 0, 2 * Math.PI);
    ctx.fill();
  });

  // Regression Line: MT = 120 + 145 * ID
  ctx.strokeStyle = "#00e5ff";
  ctx.lineWidth = 2;
  ctx.beginPath();
  const y1 = (h - 25) - (120 / 950) * (h - 45);
  const y2 = (h - 25) - ((120 + 145 * 5.5) / 950) * (h - 45);
  ctx.moveTo(40, y1);
  ctx.lineTo(w - 20, y2);
  ctx.stroke();

  ctx.fillStyle = "#64748b";
  ctx.font = "9px Consolas";
  ctx.fillText("Index of Difficulty ID = log2(2D/W+1)", w / 2 - 60, h - 6);
  ctx.fillText("MT (ms)", 6, 20);
}

function drawBioVelChart() {
  const canvas = document.getElementById("bioVelChart");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  ctx.strokeStyle = "#f59e0b";
  ctx.lineWidth = 2.5;
  ctx.beginPath();

  for (let px = 0; px < (w - 40); px += 2) {
    const tau = px / (w - 40);
    const v = 30 * Math.pow(tau, 2) - 60 * Math.pow(tau, 3) + 30 * Math.pow(tau, 4);
    const tremor = Math.sin(tau * 30.0) * 0.04 * (Math.random() - 0.5);
    const py = (h - 20) - ((v / 1.875) + tremor) * (h - 40);
    if (px === 0) ctx.moveTo(25 + px, py);
    else ctx.lineTo(25 + px, py);
  }
  ctx.stroke();

  // Contrast with robotic square velocity
  ctx.strokeStyle = "rgba(239, 68, 68, 0.4)";
  ctx.setLineDash([3, 3]);
  ctx.beginPath();
  ctx.moveTo(25, h - 20); ctx.lineTo(25, 35); ctx.lineTo(w - 20, 35); ctx.lineTo(w - 20, h - 20);
  ctx.stroke();
  ctx.setLineDash([]);

  ctx.fillStyle = "#64748b";
  ctx.font = "9px Consolas";
  ctx.fillText("Start (t=0)", 15, h - 6);
  ctx.fillText("Target (t=T)", w - 65, h - 6);
  ctx.fillStyle = "#ef4444";
  ctx.fillText("Robotic Square Velocity", w - 145, 26);
}

function drawBioTypoChart() {
  const canvas = document.getElementById("bioTypoChart");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  const lags = STATE.typoLags;
  const bins = new Array(8).fill(0);
  const minL = 180, maxL = 450;
  const bw = (maxL - minL) / 8;

  lags.forEach(l => {
    const idx = Math.min(7, Math.max(0, Math.floor((l - minL) / bw)));
    bins[idx]++;
  });

  const maxC = Math.max(1, Math.max(...bins));
  const bWidth = (w - 50) / 8;

  bins.forEach((c, i) => {
    const bH = (c / maxC) * (h - 45);
    const bx = 30 + i * bWidth;
    const by = (h - 20) - bH;
    ctx.fillStyle = "rgba(168, 85, 247, 0.65)";
    ctx.fillRect(bx + 2, by, bWidth - 4, bH);
    ctx.strokeStyle = "#a855f7";
    ctx.strokeRect(bx + 2, by, bWidth - 4, bH);
  });

  ctx.fillStyle = "#64748b";
  ctx.font = "9px Consolas";
  ctx.fillText("180ms", 25, h - 6);
  ctx.fillText("450ms", w - 45, h - 6);
}

function refreshAllBioCharts() {
  drawBioIkiChart();
  drawBioFittsChart();
  drawBioVelChart();
  drawBioTypoChart();
}

setInterval(refreshAllBioCharts, 1400);

// ==============================================================================
// 7. INITIALIZATION & REMOTE DESKTOP GATEWAY CONTROLLER
// ==============================================================================
document.addEventListener("DOMContentLoaded", () => {
  // Screen View Toggles
  const screenBtns = document.querySelectorAll(".screen-btn");
  screenBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      screenBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");

      const viewId = btn.dataset.view;
      document.querySelectorAll(".screen-view").forEach(v => {
        v.classList.toggle("active-view", v.id === viewId);
      });

      if (viewId === "viewBiometrics") {
        setTimeout(refreshAllBioCharts, 50);
      }
    });
  });

  // Audio Toggle
  const btnAudio = document.getElementById("btnAudioToggle");
  if (btnAudio) {
    btnAudio.addEventListener("click", () => {
      keyAudio.enabled = !keyAudio.enabled;
      document.getElementById("audioStateText").textContent = keyAudio.enabled ? "ON" : "OFF";
      document.getElementById("audioIco").textContent = keyAudio.enabled ? "🔊" : "🔇";
      if (keyAudio.enabled) keyAudio.init();
    });
  }

  // Live Clock in System Tray
  function updateTrayClock() {
    const now = new Date();
    let hours = now.getHours();
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    const clk = document.getElementById("trayLiveClock");
    if (clk) clk.textContent = `${hours}:${minutes} ${ampm}`;
  }
  setInterval(updateTrayClock, 1000);
  updateTrayClock();

  // Populate Chrome table with sample sales fixture
  fetch("/api/fixtures/sales").then(r => r.json()).then(data => {
    const list = document.getElementById("chromeSalesList");
    if (list && Array.isArray(data)) {
      list.innerHTML = "";
      data.forEach(p => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td><strong>${p.product_id}</strong></td>
          <td>${p.product_name}</td>
          <td>${p.category}</td>
          <td>${p.units_sold}</td>
          <td class="text-blue"><strong>$${p.revenue.toLocaleString()}</strong></td>
          <td class="text-emerald">+${p.growth_yoy}%</td>
        `;
        list.appendChild(tr);
      });
    }
  }).catch(() => {});

  // Populate Sysmon Telemetry Feed
  function refreshSysmonFeed() {
    fetch("/api/telemetry/events?limit=30").then(r => r.json()).then(data => {
      const tbody = document.getElementById("liveSysmonFeedBody");
      const countEl = document.getElementById("telemetryEventCount");
      if (countEl) countEl.textContent = (data.events || []).length;
      if (!tbody || !data.events) return;
      tbody.innerHTML = "";

      data.events.forEach(e => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td class="text-cyan font-mono">${e.event_id}</td>
          <td>${e.timestamp_utc.slice(11, 23)}</td>
          <td><strong>${e.application_name}</strong></td>
          <td class="font-mono">10424</td>
          <td>${e.action_type}</td>
          <td>${e.target_description}</td>
          <td class="font-mono">${e.action_duration_ms} ms</td>
          <td><span class="text-emerald">${e.outcome}</span></td>
        `;
        tbody.appendChild(tr);
      });
    }).catch(() => {});
  }
  setInterval(refreshSysmonFeed, 2000);
  refreshSysmonFeed();

  // Controls
  const btnRun = document.getElementById("btnRunMission");
  if (btnRun) {
    btnRun.addEventListener("click", () => {
      fetch("/api/agent/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ profile: "Data Analyst", seed: 42 })
      }).then(() => {
        document.getElementById("workstationStatusText").textContent = "LIVE: WORKING";
      });
    });
  }

  const btnPause = document.getElementById("btnPauseMission");
  if (btnPause) {
    btnPause.addEventListener("click", () => {
      STATE.isWorking = !STATE.isWorking;
      document.getElementById("workstationStatusText").textContent = STATE.isWorking ? "LIVE: WORKING" : "PAUSED: STANDBY";
      document.getElementById("pauseIco").textContent = STATE.isWorking ? "⏸" : "▶";
      fetch(STATE.isWorking ? "/api/agent/resume" : "/api/agent/pause", { method: "POST" });
    });
  }

  // Start the physical workstation loop
  setTimeout(runDesktopWorkflow, 800);
  setTimeout(refreshAllBioCharts, 400);
});
