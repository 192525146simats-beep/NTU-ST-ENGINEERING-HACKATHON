#!/usr/bin/env python3
"""
Test Suite: Synthetic Human Agent (SHA) Verification & Benchmark
Evaluates:
  1. Process Telemetry Authenticity (30% Hackathon Weight)
  2. Human Entropy & Timing / Biometrics (30% Hackathon Weight)
  3. Office Task Execution & Motor Kinematics
  4. Cloud AI Cognitive Planning & REST Endpoints
"""

import unittest
import math
import json
from synthetic_agent_core import (
    HumanMotorEngine,
    HumanTypingEngine,
    ProcessTelemetryEngine,
    AuthenticityEvaluator
)
from cloud_ai_gemini import CloudAIGeminiPlanner

class TestProcessTelemetryAuthenticity(unittest.TestCase):
    """30% Evaluation Weight: Validates OS Process Telemetry & Sysmon / EDR Realism."""

    def setUp(self):
        self.telemetry = ProcessTelemetryEngine(user="CORP\\y.bodda", computer="WKSTN-FIN-042")

    def test_process_lineage_authenticity(self):
        """Verify processes originate from legitimate Windows shell (explorer.exe)."""
        explorer_pid = self.telemetry.processes["explorer"]["pid"]
        word = self.telemetry.processes["word"]
        excel = self.telemetry.processes["excel"]
        chrome_main = self.telemetry.processes["chrome_main"]
        chrome_render = self.telemetry.processes["chrome_render"]

        # Word, Excel, Chrome must have explorer as parent
        self.assertEqual(word["ppid"], explorer_pid, "WINWORD.EXE parent must be explorer.exe")
        self.assertEqual(excel["ppid"], explorer_pid, "EXCEL.EXE parent must be explorer.exe")
        self.assertEqual(chrome_main["ppid"], explorer_pid, "chrome.exe parent must be explorer.exe")
        
        # Chrome renderer must be child of chrome main
        self.assertEqual(chrome_render["ppid"], chrome_main["pid"], "Chrome renderer parent must be Chrome main process")
        print("✓ Process Lineage Test Passed: Realistic parent-child execution hierarchy.")

    def test_sysmon_event_generation(self):
        """Verify all critical Sysmon EDR event IDs are accurately constructed."""
        # Event ID 1: Process Creation
        ev1 = self.telemetry.emit_sysmon_event(1, "word", {"CommandLine": "WINWORD.EXE /n"})
        self.assertEqual(ev1["EventID"], 1)
        self.assertIn("WINWORD.EXE", ev1["Image"])
        self.assertIn("Hashes", ev1)

        # Event ID 3: Network Connection
        ev3 = self.telemetry.emit_sysmon_event(3, "chrome_render", {"DestinationHostname": "login.microsoftonline.com"})
        self.assertEqual(ev3["EventID"], 3)
        self.assertEqual(ev3["Protocol"], "tcp")
        self.assertTrue(1024 <= ev3["SourcePort"] <= 65535)

        # Event ID 11: File Creation (Auto-Save temporary lock)
        ev11 = self.telemetry.emit_sysmon_event(11, "word", {"TargetFilename": r"C:\Users\y.bodda\Documents\~$Q3_Memo.docx"})
        self.assertEqual(ev11["EventID"], 11)
        self.assertIn("~$", ev11["TargetFilename"])

        # Event ID 22: DNS Query
        ev22 = self.telemetry.emit_sysmon_event(22, "chrome_main", {"QueryName": "login.microsoftonline.com"})
        self.assertEqual(ev22["EventID"], 22)
        self.assertEqual(ev22["QueryStatus"], "0 (SUCCESS)")
        print("✓ Sysmon Event Generation Passed: Event IDs 1, 3, 11, 22 compliant with EDR/SIEM.")

    def test_hardware_metric_fluctuations(self):
        """Verify CPU and Disk IO fluctuate realistically according to app activity."""
        metrics_word_typing = self.telemetry.update_hardware_metrics("word", is_active_typing=True)
        self.assertGreater(metrics_word_typing["cpu_pct"], 2.0)
        self.assertGreater(metrics_word_typing["ram_mb"], 4000)

        metrics_excel_calc = self.telemetry.update_hardware_metrics("excel", is_active_typing=True)
        self.assertGreater(metrics_excel_calc["cpu_pct"], 10.0, "Excel calculation should spike CPU")
        print("✓ Hardware Telemetry Test Passed: Activity-dependent CPU/RAM/Disk metrics.")


class TestHumanEntropyAndTiming(unittest.TestCase):
    """30% Evaluation Weight: Validates Biometrics, Keystroke Dynamics & Motor Kinematics."""

    def setUp(self):
        self.typing_engine = HumanTypingEngine(target_wpm=68.0, typo_rate=0.08)
        self.motor_engine = HumanMotorEngine()

    def test_fitts_law_conformance(self):
        """Verify movement duration correlates with Index of Difficulty (ID = log2(2D/W + 1))."""
        dur_short = self.motor_engine.calculate_fitts_duration(distance=50.0, target_width=40.0)
        dur_long = self.motor_engine.calculate_fitts_duration(distance=600.0, target_width=20.0)

        self.assertGreater(dur_long, dur_short, "Long high-difficulty move must take longer than short move")
        self.assertGreater(dur_short, 140.0, "Must include biological reaction latency")
        print(f"✓ Fitts's Law Test Passed: Short move={dur_short:.1f}ms, Long move={dur_long:.1f}ms.")

    def test_minimum_jerk_velocity_profile(self):
        """Verify trajectory adheres to Flash & Hogan (1985) smooth bell velocity profile."""
        traj = self.motor_engine.generate_minimum_jerk_path(
            start=(100, 100), end=(500, 400), target_width=40.0, num_points=40
        )
        points = traj["points"]
        velocities = traj["velocities"]

        self.assertEqual(len(points), 41)
        self.assertEqual(len(velocities), 41)

        # Starts and ends near zero velocity (boundary conditions of minimum jerk)
        self.assertAlmostEqual(velocities[0], 0.0, delta=1.0)
        self.assertAlmostEqual(velocities[-1], 0.0, delta=1.0)

        # Midpoint should have highest velocity (bell curve peak)
        mid_vel = velocities[20]
        self.assertGreater(mid_vel, velocities[2])
        self.assertGreater(mid_vel, velocities[-3])
        print("✓ Minimum-Jerk Kinematics Passed: Bell-shaped velocity with micro-tremor.")

    def test_keystroke_log_normal_entropy(self):
        """Verify Inter-Key Intervals follow Log-Normal distribution and have high Shannon entropy."""
        ikis = [self.typing_engine.sample_iki("a", "b") for _ in range(200)]
        mean_iki = sum(ikis) / len(ikis)
        std_iki = math.sqrt(sum((x - mean_iki) ** 2 for x in ikis) / len(ikis))
        cv = std_iki / mean_iki

        # Coefficient of variation for humans is ~0.25 to 0.45 (bots are ~0.0)
        self.assertTrue(0.20 <= cv <= 0.60, f"CV={cv:.3f} must reflect realistic human variation")

        # Evaluate through authenticity benchmark
        metrics = AuthenticityEvaluator.evaluate_keystroke_distribution(ikis)
        self.assertGreater(metrics["shannon_entropy_bits"], 3.0, "Entropy must exceed bot threshold")
        self.assertGreater(metrics["authenticity_score_pct"], 95.0, "Must achieve high human-likeness score")
        print(f"✓ Keystroke Entropy Passed: Mean={mean_iki:.1f}ms, Entropy={metrics['shannon_entropy_bits']:.2f} bits, Score={metrics['authenticity_score_pct']:.1f}%.")

    def test_typo_realization_lag_and_backspacing(self):
        """Verify typo generation, motor momentum overrun, and cognitive backspace pauses."""
        text = "Enterprise Architecture Specification Document"
        events = self.typing_engine.simulate_typing_sequence(text)

        has_backspace = any(ev.get("key") == "Backspace" for ev in events)
        has_cognitive_pause = any(ev.get("action") == "cognitive_pause" for ev in events)

        # At least one typo should occur given 8% rate on long string
        if has_cognitive_pause:
            pause_ev = next(ev for ev in events if ev.get("action") == "cognitive_pause")
            self.assertGreater(pause_ev["pause_ms"], 200.0, "Typo realization pause must be >= 200ms (human cognitive limit)")
            self.assertTrue(has_backspace, "Typo must be corrected with Backspace")
            print(f"✓ Typo Realization Test Passed: Cognitive hesitation pause={pause_ev['pause_ms']:.1f}ms followed by Backspaces.")


class TestCloudAIGeminiPlanner(unittest.TestCase):
    """Validates Next-Gen Cloud AI & Gemini Cognitive Planning engine."""

    def setUp(self):
        self.planner = CloudAIGeminiPlanner()

    def test_workflow_decomposition(self):
        """Verify task decomposition into sequential office micro-actions."""
        plan = self.planner.plan_workflow("financial_reconciliation")
        self.assertIn("cognitive_phases", plan)
        self.assertGreaterEqual(len(plan["cognitive_phases"]), 3)

        phases = plan["cognitive_phases"]
        apps = [p["app"] for p in phases]
        self.assertIn("excel", apps, "Must include spreadsheet manipulation")
        self.assertIn("word", apps, "Must include document creation")
        self.assertIn("chrome", apps, "Must include web browsing")
        print(f"✓ Cloud AI Planner Passed: {len(phases)} cognitive phases across {set(apps)}.")

if __name__ == "__main__":
    unittest.main()
