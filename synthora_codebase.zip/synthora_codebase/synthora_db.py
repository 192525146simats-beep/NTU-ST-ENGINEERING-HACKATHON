#!/usr/bin/env python3
"""
Synthora Persistent Database Subsystem (SQLite3)
Manages sessions, structured telemetry events, task execution states, and evaluation records.
"""

import os
import sqlite3
import json
import time
from typing import List, Dict, Any, Optional

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "synthora.db")

class SynthoraDatabase:
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._init_db()

    def get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # 1. Sessions table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                status TEXT NOT NULL,
                task_description TEXT NOT NULL,
                behavior_profile TEXT NOT NULL,
                random_seed INTEGER NOT NULL,
                total_events INTEGER DEFAULT 0,
                elapsed_seconds REAL DEFAULT 0.0,
                output_docx_path TEXT,
                output_xlsx_path TEXT,
                verification_rate REAL DEFAULT 100.0,
                metadata TEXT
            )
            """)

            # 2. Telemetry Events table (Complete 17-field schema from Section 9)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS telemetry_events (
                event_id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                sequence_number INTEGER NOT NULL,
                timestamp_utc TEXT NOT NULL,
                monotonic_elapsed_ms REAL NOT NULL,
                action_type TEXT NOT NULL,
                application_name TEXT NOT NULL,
                target_description TEXT NOT NULL,
                action_start_iso TEXT NOT NULL,
                action_complete_iso TEXT NOT NULL,
                action_duration_ms REAL NOT NULL,
                interaction_interval_ms REAL NOT NULL,
                execution_mode TEXT NOT NULL,
                event_source TEXT NOT NULL,
                outcome TEXT NOT NULL,
                error_info TEXT,
                recovery_status TEXT,
                verification_status TEXT,
                behavior_profile TEXT NOT NULL,
                random_seed INTEGER NOT NULL,
                raw_payload TEXT,
                FOREIGN KEY (session_id) REFERENCES sessions(session_id)
            )
            """)

            # 3. Evaluation Benchmarks table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS evaluation_results (
                eval_id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                timestamp_utc TEXT NOT NULL,
                telemetry_authenticity_score REAL NOT NULL,
                human_entropy_score REAL NOT NULL,
                shannon_entropy_bits REAL NOT NULL,
                fitts_r2 REAL NOT NULL,
                mean_iki_ms REAL NOT NULL,
                cv_ratio REAL NOT NULL,
                ks_pvalue REAL NOT NULL,
                typo_realization_ms REAL NOT NULL,
                verdict TEXT NOT NULL,
                FOREIGN KEY (session_id) REFERENCES sessions(session_id)
            )
            """)
            conn.commit()

    def record_session(self, session_data: Dict[str, Any]):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT OR REPLACE INTO sessions (
                session_id, created_at, status, task_description,
                behavior_profile, random_seed, total_events, elapsed_seconds,
                output_docx_path, output_xlsx_path, verification_rate, metadata
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                session_data["session_id"],
                session_data.get("created_at", time.strftime("%Y-%m-%dT%H:%M:%SZ")),
                session_data.get("status", "working"),
                session_data.get("task_description", "Default Demonstration Task"),
                session_data.get("behavior_profile", "Data Analyst"),
                session_data.get("random_seed", 42),
                session_data.get("total_events", 0),
                session_data.get("elapsed_seconds", 0.0),
                session_data.get("output_docx_path", ""),
                session_data.get("output_xlsx_path", ""),
                session_data.get("verification_rate", 100.0),
                json.dumps(session_data.get("metadata", {}))
            ))
            conn.commit()

    def update_session_status(self, session_id: str, status: str, total_events: int = 0, elapsed: float = 0.0):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            UPDATE sessions 
            SET status = ?, total_events = ?, elapsed_seconds = ?
            WHERE session_id = ?
            """, (status, total_events, elapsed, session_id))
            conn.commit()

    def insert_telemetry_event(self, ev: Dict[str, Any]):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT OR REPLACE INTO telemetry_events (
                event_id, session_id, sequence_number, timestamp_utc,
                monotonic_elapsed_ms, action_type, application_name, target_description,
                action_start_iso, action_complete_iso, action_duration_ms, interaction_interval_ms,
                execution_mode, event_source, outcome, error_info,
                recovery_status, verification_status, behavior_profile, random_seed, raw_payload
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                ev["event_id"],
                ev["session_id"],
                ev["sequence_number"],
                ev["timestamp_utc"],
                ev["monotonic_elapsed_ms"],
                ev["action_type"],
                ev["application_name"],
                ev["target_description"],
                ev["action_start_iso"],
                ev["action_complete_iso"],
                ev["action_duration_ms"],
                ev["interaction_interval_ms"],
                ev.get("execution_mode", "autonomous_synthetic"),
                ev.get("event_source", "kernel_ebpf_hook"),
                ev.get("outcome", "SUCCESS"),
                ev.get("error_info", ""),
                ev.get("recovery_status", "NORMAL"),
                ev.get("verification_status", "VERIFIED"),
                ev.get("behavior_profile", "Data Analyst"),
                ev.get("random_seed", 42),
                json.dumps(ev.get("raw_payload", {}))
            ))
            conn.commit()

    def get_events(self, session_id: Optional[str] = None, limit: int = 150) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            if session_id:
                cursor.execute("SELECT * FROM telemetry_events WHERE session_id = ? ORDER BY sequence_number DESC LIMIT ?", (session_id, limit))
            else:
                cursor.execute("SELECT * FROM telemetry_events ORDER BY timestamp_utc DESC LIMIT ?", (limit,))
            rows = cursor.fetchall()
            return [dict(r) for r in rows]

    def get_sessions(self, limit: int = 10) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM sessions ORDER BY created_at DESC LIMIT ?", (limit,))
            return [dict(r) for r in cursor.fetchall()]
