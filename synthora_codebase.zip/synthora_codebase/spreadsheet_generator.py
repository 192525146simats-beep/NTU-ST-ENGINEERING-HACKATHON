#!/usr/bin/env python3
"""
Synthora Excel Workbook (.xlsx) Generator using openpyxl.
Generates fully functional Microsoft Excel workbooks with formatted tables, formulas, and styles.
"""

import os
from typing import List, Dict, Any, Optional
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

class ExcelWorkbookBuilder:
    """Creates formatted Microsoft Excel workbooks with calculations and visual styling."""

    def __init__(self, title: str = "Sales Analysis"):
        self.wb = openpyxl.Workbook()
        self.ws = self.wb.active
        self.ws.title = title[:31]

    def build_sales_report(self, data: List[Dict[str, Any]], filepath: str) -> str:
        os.makedirs(os.path.dirname(os.path.abspath(filepath)), exist_ok=True)
        ws = self.ws

        # Set sheet title banner
        ws.merge_cells("A1:H1")
        title_cell = ws["A1"]
        title_cell.value = "SYNTHORA // ENTERPRISE PRODUCT SALES & REVENUE AUDIT"
        title_cell.font = Font(name="Segoe UI", size=14, bold=True, color="FFFFFF")
        title_cell.fill = PatternFill(start_color="0066FF", end_color="0066FF", fill_type="solid")
        title_cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[1].height = 36

        # Subtitle
        ws.merge_cells("A2:H2")
        sub_cell = ws["A2"]
        sub_cell.value = "Autonomous Synthetic Human Agent Task Execution Report • Date: October 2026"
        sub_cell.font = Font(name="Segoe UI", size=9, italic=True, color="64748B")
        sub_cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[2].height = 20

        # Headers
        headers = [
            "Product ID", "Product Name", "Category", 
            "Units Sold", "Unit Price ($)", "Gross Revenue ($)", 
            "Margin (%)", "YoY Growth (%)"
        ]
        ws.append([])  # Blank row 3
        ws.append(headers)  # Row 4
        ws.row_dimensions[4].height = 24

        hdr_fill = PatternFill(start_color="0F172A", end_color="0F172A", fill_type="solid")
        hdr_font = Font(name="Segoe UI", size=10, bold=True, color="F8FAFC")
        thin_border = Border(
            left=Side(style='thin', color='CBD5E1'),
            right=Side(style='thin', color='CBD5E1'),
            top=Side(style='thin', color='CBD5E1'),
            bottom=Side(style='thin', color='CBD5E1')
        )

        for col_idx in range(1, len(headers) + 1):
            cell = ws.cell(row=4, column=col_idx)
            cell.fill = hdr_fill
            cell.font = hdr_font
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = thin_border

        # Populate rows
        start_row = 5
        for item in data:
            ws.append([
                item["product_id"],
                item["product_name"],
                item["category"],
                item["units_sold"],
                item["unit_price"],
                f"=D{start_row}*E{start_row}",  # Dynamic formula: Units * Price
                item["margin_pct"] / 100.0,
                item["growth_yoy"] / 100.0
            ])
            start_row += 1

        end_row = start_row - 1

        # Summary Total Row
        ws.append([
            "TOTAL / AVG",
            "Portfolio Aggregate",
            "—",
            f"=SUM(D5:D{end_row})",
            f"=AVERAGE(E5:E{end_row})",
            f"=SUM(F5:F{end_row})",
            f"=AVERAGE(G5:G{end_row})",
            f"=AVERAGE(H5:H{end_row})"
        ])
        total_row = start_row
        ws.row_dimensions[total_row].height = 26

        tot_fill = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")
        tot_font = Font(name="Segoe UI", size=10, bold=True, color="0066FF")

        for col_idx in range(1, len(headers) + 1):
            cell = ws.cell(row=total_row, column=col_idx)
            cell.fill = tot_fill
            cell.font = tot_font
            cell.border = thin_border

        # Formatting data cells
        for r in range(5, end_row + 1):
            ws.cell(row=r, column=4).number_format = '#,##0'
            ws.cell(row=r, column=5).number_format = '$#,##0.00'
            ws.cell(row=r, column=6).number_format = '$#,##0.00'
            ws.cell(row=r, column=7).number_format = '0.0%'
            ws.cell(row=r, column=8).number_format = '0.0%'

        # Format totals
        ws.cell(row=total_row, column=4).number_format = '#,##0'
        ws.cell(row=total_row, column=5).number_format = '$#,##0.00'
        ws.cell(row=total_row, column=6).number_format = '$#,##0.00'
        ws.cell(row=total_row, column=7).number_format = '0.0%'
        ws.cell(row=total_row, column=8).number_format = '0.0%'

        # Auto-fit column widths
        for col in ws.columns:
            max_len = max(len(str(cell.value or '')) for cell in col)
            col_letter = get_column_letter(col[0].column)
            ws.column_dimensions[col_letter].width = max(max_len + 4, 14)

        self.wb.save(filepath)
        return filepath
